<template>
  <div>
    
  </div>
</template>

<script>
export default {
  name: 'Cur-6',
  data () {
    return {
      
    }
  }
}
</script>
<style>

</style>
