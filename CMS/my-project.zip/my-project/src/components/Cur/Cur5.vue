<template>
  <div>
    
  </div>
</template>

<script>
export default {
  name: 'Cur-5',
  data () {
    return {
      
    }
  }
}
</script>
<style>

</style>
