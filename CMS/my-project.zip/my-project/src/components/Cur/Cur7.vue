<template>
  <div>
  	<div class="navimg"></div>
  	<div class="height50"></div>
  	<div>
  		<Button type="ghost" style="margin-right:-5px;vertical-align: top;">部门</Button>
  		<Select v-model="model1" style="width:150px;margin-right:45px;">
	        <Option v-for="item in cityList" :value="item.value" :key="item.value">{{ item.label }}</Option>
	    </Select>
	    <Button type="ghost" style="margin-right:-5px;vertical-align: top;">角色</Button>
  		<Select v-model="model2" style="width:150px;margin-right:45px;">
	        <Option v-for="item in cityList" :value="item.value" :key="item.value">{{ item.label }}</Option>
	    </Select>
	    <Button type="ghost" style="margin-right:-5px;vertical-align: top;">所属管理组</Button>
  		<Select v-model="model3" style="width:150px;margin-right:45px;">
	        <Option v-for="item in cityList" :value="item.value" :key="item.value">{{ item.label }}</Option>
	    </Select>
	    <Button type="ghost" style="margin-right:-5px;vertical-align: top;">状态</Button>
  		<Select v-model="model4" style="width:150px;margin-right:45px;" >
	        <Option v-for="item in cityList" :value="item.value" :key="item.value">{{ item.label }}</Option>
	    </Select>
  	</div> 
  	<div style="margin-top:50px;">
  		<Button type="ghost" style="margin-right:-5px;vertical-align: top;">用户名</Button>
  		<Input v-model="value1" style="width: 150px;margin-right:45px;"></Input>
  		<Button type="ghost" style="margin-right:-5px;vertical-align: top;">真实姓名</Button>
  		<Input v-model="value2" style="width: 150px;margin-right:45px;"></Input>
  		<Button type="ghost" style="margin-right:-5px;vertical-align: top;">手机号码</Button>
  		<Input v-model="value3" style="width: 150px;margin-right:45px;"></Input>
  	</div>
  	<div class="height50"></div>
  	<el-button type="primary">查询</el-button>
    <el-button type="primary">重置</el-button>
    <el-button type="primary" @click="xinzeng">新增</el-button>
    <div class="height50"></div>
    <div class="liebiao">
      <div class="btitle">
        <span style="width:220px">操作</span>
        <span style="width:100px">用户名</span>
        <span style="width:90px">姓名</span>
        <span style="width:180px">手机号码</span>
        <span style="width:240px">身份证号</span>
        <span style="width:100px">角色</span>
w        <span style="width:100px">部门</span>
        <span style="width:100px">所属管理组</span>
        <span style="width:100px">状态</span>
        <span style="width:200px">备注</span>
      </div>
      <div class="tr" v-for="(item,index) in list">
        <el-button type="primary" size="mini" @click="zhuxiao(index)">注销</el-button>
        <el-button type="primary" size="mini" @click="shenyong(index)">冻结|解冻</el-button>
        <el-button type="primary" size="mini" @click="chongzhi(index)">重置密码</el-button>
        <span style="width:100px">{{item.c1}}</span>
        <span style="width:90px" @click="xiangqing(index)">{{item.c2}}</span>
        <span style="width:180px">{{item.c3}}</span>
        <span style="width:240px">{{item.c4}}</span>
        <span style="width:100px">{{item.c5}}</span>
        <span style="width:100px">{{item.c6}}</span>
        <span style="width:100px">{{item.c7}}</span>
        <span style="width:100px">{{item.c8}}</span>
        <span style="width:200px">{{item.c9}}</span>
      </div>
    </div>
    <Modal v-model="chongzh" title="重置密码" :mask-closable="false">
          <div>你正在重置员工"{{list1.c3}}"的账户登录密码?</div>
          <RadioGroup v-model="vertical" vertical @click="dianji">
		        <Radio label="apple" >
		            <span >设为默认</span>
		            <span>默认密码为【juncheng123】</span>
		        </Radio>
		        <Radio label="android" >
		            <span>手动输入</span>
		            <Input v-model="value3" style="width: 150px;"></Input>
		        </Radio>
		    </RadioGroup>
    </Modal>
    <Modal v-model="dongjie" title="冻结帐号" :mask-closable="false">
          <div>你正在重置员工"{{list1.c3}}"的账户登录密码?</div>
    </Modal>
    <Modal v-model="jiedong" title="解冻帐号" :mask-closable="false">
          <div>你正在重置员工"{{list1.c3}}"的账户登录密码?</div>
    </Modal>
    <Modal v-model="zhuxiao" title="注销帐号" :mask-closable="false" ok-text="确定注销" @on-ok="ok">
          <div>你确定要注销员工"{{list2.c2}}"的帐号?</div>
      </Modal>
  </div>
</template>

<script>
export default {
  name: 'Cur-7',
  data () {
    return {
      model1:'',
      model2:'',
      model3:'',
      model4:'',
      value1:'',
      value2:'',
      value3:'',
      vertical:'apple',
      chongzh:false,
      dongjie:false,
      jiedong:false,
      cityList:[
      		{
                value: 'New York',
                label: 'New York'
            },
            {
                value: 'New York',
                label: 'New York'
            },
            {
                value: 'New York',
                label: 'New York'
            },
      ],
      list:[
        {
          c1:"Ln123",
          c2:"张三",
          c3:"18842872661",
          c4:"210282199602112110",
          c5:"催收人员",
          c6:"催收部",
          c7:"催收组",
          c8:"正常",
          c9:""
        },
        {
          c1:"Ln123",
          c2:"张三",
          c3:"18842872661",
          c4:"210282199602112110",
          c5:"催收人员",
          c6:"催收部",
          c7:"催收组",
          c8:"正常",
          c9:""
        },
        {
          c1:"Ln123",
          c2:"张三",
          c3:"18842872661",
          c4:"210282199602112110",
          c5:"催收人员",
          c6:"催收部",
          c7:"催收组",
          c8:"正常",
          c9:""
        },
      ],
      list1:{}
    }
  },methods:{
  	chongzhi(index){
  		this.list1 = this.list[index]
  		this.chongzh = true;
  	},ok(index){

  	}
  }
}
</script>
<style>
.navimg{
	background:url(../../../static/buzhou.png) no-repeat;
	height:70px;
	background-size: 100%;

}
</style>
